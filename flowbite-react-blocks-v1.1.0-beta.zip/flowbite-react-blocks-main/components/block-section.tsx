import { Button } from "flowbite-react";
import type { FC, PropsWithChildren } from "react";
import { FaGithub } from "react-icons/fa";

export interface BlockSectionProps extends PropsWithChildren {
  description: string;
  githubLink: string;
  title: string;
}

const BlockSection: FC<BlockSectionProps> = function ({
  children,
  description,
  githubLink,
  title,
}) {
  return (
    <section className="mb-12 p-6">
      <div className="mb-8 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <div>
          <header>
            <h2 className="mb-1 text-2xl font-semibold tracking-tight text-gray-900 dark:text-white">
              {title}
            </h2>
          </header>
          <p className="text-lg text-gray-500 dark:text-gray-400 lg:mb-0 lg:max-w-2xl">
            {description}
          </p>
        </div>
        <Button href={githubLink} target="_blank">
          <FaGithub className="mr-3 h-5 w-5" />
          View on GitHub
        </Button>
      </div>
      <div className="w-full rounded-xl border border-gray-200 bg-white bg-gradient-to-r p-2 px-4 dark:border-gray-700 dark:bg-gray-800 sm:p-6">
        {children}
      </div>
    </section>
  );
};

export default BlockSection;
